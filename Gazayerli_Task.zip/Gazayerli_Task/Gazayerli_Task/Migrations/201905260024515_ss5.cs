namespace Gazayerli_Task.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ss5 : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
