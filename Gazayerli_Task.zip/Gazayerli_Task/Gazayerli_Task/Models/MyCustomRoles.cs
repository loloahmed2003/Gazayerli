﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Gazayerli_Task.Models
{
    public struct MyCustomRoles
    {
        //Admin = 1,
        //Lawyer = 2,
        //Client = 3
        public const string Admin = "Admin";
        public const string Lawyer = "Lawyer";
        public const string Client = "Client";
    }
}